from typing import Optional
from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from passlib.context import CryptContext
from fastapi.middleware.cors import CORSMiddleware
import pymysql
import jwt
import datetime

# JWT Secret Key
SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"

app = FastAPI()

# Enable CORS to allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins (change this in production)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Password Hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Database Connection Function
def get_db_connection():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="yashord",
        database="ride_sharing",
        cursorclass=pymysql.cursors.DictCursor
    )

# Pydantic Model for Login Request
class UserLogin(BaseModel):
    email: str
    password: str

# Generate JWT Token
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Authenticate User
def authenticate_user(email: str, password: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT userID, email, password FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()
    conn.close()

    if user and pwd_context.verify(password, user["password"]):  # ✅ Ensure password is verified correctly
        return user
    return None

# Login Route - Generate Token
@app.post("/token")
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect username or password")

    token = create_access_token({"sub": user["email"]})
    return {"access_token": token, "token_type": "bearer"}

# Get Logged-in User Info
@app.get("/users/me")
def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return {"email": email}
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    
# Ride Request Model
class RideCreateRequest(BaseModel):
    bookerID: int
    destination: str
    date: str  # YYYY-MM-DD format
    time: str  # HH:MM:SS format
    seats: int
    cost: float

# Ride Creation API
@app.post("/create_ride")
def create_ride(request: RideCreateRequest):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        print("Received request:", request.dict())

        # Validate bookerID
        cursor.execute("SELECT userID FROM users WHERE userID = %s", (request.bookerID,))
        if not cursor.fetchone():
            raise HTTPException(status_code=400, detail="Invalid bookerID: User does not exist.")

        # Insert ride
        query = """
        INSERT INTO rides (bookerID, destination, date, time, seats, cost, status) 
        VALUES (%s, %s, %s, %s, %s, %s, 'On-Way')
        """
        cursor.execute(query, (request.bookerID, request.destination, request.date, request.time, request.seats, request.cost))
        conn.commit()

        return {"message": "Ride created successfully", "rideID": cursor.lastrowid}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.get("/search_rides")
def search_rides(destination: Optional[str] = None, date: Optional[str] = None, seats: Optional[int] = None):
    conn = get_db_connection()
    cursor = conn.cursor(pymysql.cursors.DictCursor)

    try:
        query = "SELECT * FROM rides WHERE 1=1"
        params = []
        if destination:
            query += " AND destination = %s"
            params.append(destination)
        if date:
            query += " AND date = %s"
            params.append(date)
        if seats:
            query += " AND seats >= %s"
            params.append(seats)

        cursor.execute(query, tuple(params))
        rides = cursor.fetchall()  # Fetch only once

        return {"rides": rides}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        cursor.close()
        conn.close()


# Model for joining a ride
class JoinRideRequest(BaseModel):
    userID: int
    rideID: int

@app.post("/request_ride")
def request_ride(request: JoinRideRequest):
    conn = get_db_connection()
    cursor = conn.cursor(pymysql.cursors.DictCursor)  # ✅ Fetch rows as dict

    try:
        # Check if the ride exists and get available seats
        cursor.execute("SELECT seats FROM rides WHERE rideID = %s", (request.rideID,))
        ride = cursor.fetchone()

        if not ride:
            raise HTTPException(status_code=404, detail="Ride not found")

        available_seats = ride.get("seats",0)  # ✅ Access seats safely

        if available_seats <= 0:
            raise HTTPException(status_code=400, detail="No available seats")

        # Insert ride request
        cursor.execute(
            "INSERT INTO ride_requests (rideID, userID, status) VALUES (%s, %s, 'Pending')",
            (request.rideID, request.userID)
        )

        conn.commit()
        return {"message": "Ride request submitted successfully"}

    except Exception as e:
        conn.rollback()
        print(f"Error in /request_ride: {e}")  # Debugging log
        print(traceback.format_exc())  # Full error traceback

        raise HTTPException(status_code=500, detail=str(e))
    
    finally:
        cursor.close()
        conn.close()


class ApproveRideRequest(BaseModel):
    requestID: int
    approve: bool

def get_db_connection():
    return pymysql.connect(host="localhost", user="root", password="yashord", database="ride_sharing", cursorclass=pymysql.cursors.DictCursor)

@app.post("/approve_ride_request")
def approve_ride_request(request: ApproveRideRequest):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if request exists
        cursor.execute("SELECT rideID, userID, status FROM ride_requests WHERE requestID = %s", (request.requestID,))
        ride_request = cursor.fetchone()

        if not ride_request:
            raise HTTPException(status_code=404, detail="Ride request not found")

        rideID, userID, status = ride_request["rideID"], ride_request["userID"], ride_request["status"]

        if status != "Pending":
            raise HTTPException(status_code=400, detail="Request is already processed")

        if request.approve:
            # Ensure user exists in users table before proceeding
            cursor.execute("SELECT userID FROM users WHERE userID = %s", (userID,))
            if not cursor.fetchone():
                raise HTTPException(status_code=400, detail="User does not exist")

            # Get bookerID separately
            cursor.execute("SELECT bookerID FROM rides WHERE rideID = %s", (rideID,))
            booker = cursor.fetchone()
            if not booker:
                raise HTTPException(status_code=400, detail="Ride does not exist")
            
            bookerID = booker["bookerID"]

            # Ensure there are available seats before confirming
            cursor.execute("SELECT seats FROM rides WHERE rideID = %s", (rideID,))
            ride_info = cursor.fetchone()

            if not ride_info or ride_info["seats"] <= 0:
                raise HTTPException(status_code=400, detail="No available seats")

            # Move request to ride_confirmations
            cursor.execute("""
                INSERT INTO ride_confirmations (rideID, bookerID, passengerID)
                VALUES (%s, %s, %s)
            """, (rideID, bookerID, userID))
            
            # Update available seats only if seats are greater than 0
            cursor.execute("UPDATE rides SET seats = seats - 1 WHERE rideID = %s AND seats > 0", (rideID,))
            cursor.execute("UPDATE ride_requests SET status = 'Accepted' WHERE requestID = %s", (request.requestID,))
        else:
            cursor.execute("UPDATE ride_requests SET status = 'Declined' WHERE requestID = %s", (request.requestID,))

        conn.commit()
        return {"message": "Ride request processed successfully"}

    except pymysql.MySQLError as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"MySQL Error: {str(e)}")

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        cursor.close()
        conn.close()

